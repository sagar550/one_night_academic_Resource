#Admin Dashborad
![image](https://github.com/abhisheknagaich123/one_night_academic_resource/assets/77282305/617c2270-e17c-4a46-b330-33d8d08337b8)
![image](https://github.com/abhisheknagaich123/one_night_academic_resource/assets/77282305/a96f5c07-deca-4ec5-9aab-1c75d4092399)
![image](https://github.com/abhisheknagaich123/one_night_academic_resource/assets/77282305/005b9640-9749-4090-92b1-e780e2d8de7c)
add the subject name
![image](https://github.com/abhisheknagaich123/one_night_academic_resource/assets/77282305/0da11db7-0db0-4fc0-8521-cce7c950f43f)
add subject information
![image](https://github.com/abhisheknagaich123/one_night_academic_resource/assets/77282305/6123f4c8-d4f5-49db-b12d-a24ebc95c185)
![image](https://github.com/abhisheknagaich123/one_night_academic_resource/assets/77282305/4eccf96b-1392-4b2b-b0a1-8daa25539d2c)
## user interface for Student's
![image](https://github.com/abhisheknagaich123/one_night_academic_resource/assets/77282305/ef342d74-083b-4a51-b118-d901a4b2d711)
![image](https://github.com/abhisheknagaich123/one_night_academic_resource/assets/77282305/cddc6700-c2c3-479e-899c-3d9379fd6b17)
![image](https://github.com/abhisheknagaich123/one_night_academic_resource/assets/77282305/85efdbe7-6416-48d3-baa2-3b0db98efc60)
![image](https://github.com/abhisheknagaich123/one_night_academic_resource/assets/77282305/4cf569a1-d8af-4605-b159-0a9e81a9e25e)

![image](https://github.com/abhisheknagaich123/one_night_academic_resource/assets/77282305/a40dbd3e-9106-41ec-b029-1c5f105e5658)
![image](https://github.com/abhisheknagaich123/one_night_academic_resource/assets/77282305/1789440d-6fdc-4a38-a2e0-e9752f729aed)







