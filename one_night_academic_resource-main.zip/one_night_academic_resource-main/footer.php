
<footer style="background-color: #deded5;">

<div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
    © 2024 Copyright:
    <a class="text-dark" href="#">OneNightAcademicResource.com</a>
</div>
<!-- Copyright -->
</footer>