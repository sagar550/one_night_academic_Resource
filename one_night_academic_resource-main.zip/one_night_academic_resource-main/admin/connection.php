<?php
session_start();
$con=mysqli_connect("localhost","root","","gla");


?>